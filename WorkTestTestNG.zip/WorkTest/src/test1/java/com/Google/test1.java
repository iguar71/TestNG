package com.Google;

import com.codeborne.selenide.CollectionCondition;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;

import static com.codeborne.selenide.CollectionCondition.size;
import static com.codeborne.selenide.CollectionCondition.sizeGreaterThan;
import static com.codeborne.selenide.Condition.text;
import static com.codeborne.selenide.Selenide.$;
import static com.codeborne.selenide.Selenide.$$;
import static com.codeborne.selenide.Selenide.open;

public class test1 {
    private static String    homeUrl = "http://knickerbocker-hotel-new-york.booked.net/en/";
    private static WebDriver driver;

    @Test(groups = {"smoke","regr"})
    public void googleSearch() throws IOException, InterruptedException {
  //      driver = new ChromeDriver();
        Configuration.browser = "Chrome";
        WebDriverManager.chromedriver().setup();
       // open(homeUrl);
        System.out.println("Done 1");

    }
    @Test(groups = {"smoke","regr"})
    public void task2() throws IOException, InterruptedException {
        System.out.println("Done 2");

    }
    @Test(groups = {"smoke","regr"})
    public void task3() throws IOException, InterruptedException {
        System.out.println("Done 3");
        Assert.assertEquals(1,2,"ddd");
        SoftAssert sa = new SoftAssert();
    }


}
