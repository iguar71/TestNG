package com.Google;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

    public HomePage(WebDriver driver) {
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }
    public WebDriver driver;

    //xpaths <li class="nav-item js-gtm-nav-item-overview active">
    public final String Overview_Tab_Xpath			="//div[4]//a[text()='Overview']";
    public final String Facilities_Tab_Xpath			="//div[4]//a[text()='Facilities']";
    public final String Rooms_Tab_Xpath			    ="//div[3]//a[text()='Rooms']";
    public final String Location_Tab_Xpath			="//div[4]//a[text()='Location']";
    public final String Reviews_Tab_Xpath			    ="//div[4]//a[text()='Reviews']";
    public final String DateFrom_Xpath			    ="//div[@class='check-date-wrapper clearfix'][1]";
    public final String DateTo_Xpath			        ="//div[@class='check-date-wrapper clearfix'][2]";
    public final String Arrow_Xpath			        ="//*[name()='svg' and @xpath=1]";
    public final String Month_Name_Xpath			    ="//div[@class='month-element'][1]";

    //WebElements
    @FindBy(xpath = Overview_Tab_Xpath)
    public WebElement Overview_Tab;

    @FindBy(xpath = Facilities_Tab_Xpath)
    public WebElement Facilities_Tab;

    @FindBy(xpath = Rooms_Tab_Xpath)
    public WebElement Rooms_Tab;

    @FindBy(xpath = Location_Tab_Xpath)
    public WebElement Location_Tab;

    @FindBy(xpath = Reviews_Tab_Xpath)
    public WebElement Reviews_Tab;

    @FindBy(xpath = DateFrom_Xpath)
    public WebElement DateFrom;

    @FindBy(xpath = DateTo_Xpath)
    public WebElement DateTo;

    @FindBy(xpath = Arrow_Xpath)
    public WebElement Arrow;

    @FindBy(xpath = Month_Name_Xpath)
    public WebElement Month_Name;


}
